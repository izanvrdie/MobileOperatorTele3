﻿using System.Windows;

namespace MobileOperatorTele3
{
    public partial class App : Application
    {
    }
}