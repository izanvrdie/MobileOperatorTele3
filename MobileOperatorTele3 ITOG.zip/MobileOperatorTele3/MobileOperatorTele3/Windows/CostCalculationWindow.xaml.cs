﻿using System;
using System.Linq;
using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class CostCalculationWindow : Window
    {
        public CostCalculationWindow()
        {
            InitializeComponent();
            LoadClients();
            dtpMonth.SelectedDate = DateTime.Now;
        }

        private void LoadClients()
        {
            using (var db = new user14_dbEntities())
            {
                var clients = db.Kusovoi_Clients
                    .Select(c => new
                    {
                        c.ClientID,
                        Display = c.FullName + " (" + c.PhoneNumber + ")"
                    })
                    .ToList();

                cmbClient.ItemsSource = clients;
                cmbClient.DisplayMemberPath = "Display";
                cmbClient.SelectedValuePath = "ClientID";
            }
        }

        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (cmbClient.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int clientId = (int)cmbClient.SelectedValue;
            DateTime date = dtpMonth.SelectedDate ?? DateTime.Now;
            int month = date.Month;
            int year = date.Year;

            using (var db = new user14_dbEntities())
            {
                var client = db.Kusovoi_Clients.Find(clientId);
                var tariff = db.Kusovoi_Tariffs.Find(client.TariffID);

                var calls = db.Kusovoi_Calls
                    .Where(c => c.ClientID == clientId
                             && c.CallDate.Month == month
                             && c.CallDate.Year == year)
                    .ToList();

                decimal callsCost = calls.Sum(c => c.Cost);
                decimal total = tariff.MonthlyFee + callsCost;

                txtResult.Text =
                    "КЛИЕНТ" + Environment.NewLine +
                    "───────────────────────────" + Environment.NewLine +
                    "ФИО: " + client.FullName + Environment.NewLine +
                    "Телефон: " + client.PhoneNumber + Environment.NewLine +
                    "Тариф: " + tariff.Name + Environment.NewLine +
                    "Текущий баланс: " + client.Balance.ToString("F2") + " руб." + Environment.NewLine +
                    Environment.NewLine +
                    "ПЕРИОД" + Environment.NewLine +
                    "───────────────────────────" + Environment.NewLine +
                    month.ToString("D2") + "." + year + Environment.NewLine +
                    Environment.NewLine +
                    "РАСЧЁТ" + Environment.NewLine +
                    "───────────────────────────" + Environment.NewLine +
                    "Абонентская плата: " + tariff.MonthlyFee.ToString("F2") + " руб." + Environment.NewLine +
                    "Количество звонков: " + calls.Count + Environment.NewLine +
                    "Стоимость звонков: " + callsCost.ToString("F2") + " руб." + Environment.NewLine +
                    Environment.NewLine +
                    "ИТОГО К ОПЛАТЕ: " + total.ToString("F2") + " руб.";
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}