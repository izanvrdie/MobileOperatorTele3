﻿using MobileOperatorTele3;
using System.Linq;
using System.Windows;

namespace MobileOperatorTele3.Windows
{
    public partial class TariffsWindow : Window
    {
        private string userRole;

        public TariffsWindow(string role)
        {
            InitializeComponent();
            this.userRole = role;
            ConfigureByRole();
            LoadTariffs();
        }

        private void ConfigureByRole()
        {
            bool isAdmin = userRole == "Admin";

            // Кнопки «Добавить» и «Удалить» — только админ
            btnAdd.Visibility = isAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;

            btnDelete.Visibility = isAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void LoadTariffs()
        {
            using (var db = new user14_dbEntities())
            {
                var tariffs = db.Kusovoi_Tariffs
                    .Select(t => new
                    {
                        t.TariffID,
                        Название = t.Name,
                        АбонПлата = t.MonthlyFee,
                        ЦенаЗвонка = t.CallPrice,
                        ЦенаSMS = t.SMSPrice,
                        ЦенаИнтернета = t.InternetPrice
                    })
                    .ToList();

                dgvTariffs.ItemsSource = tariffs;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new TariffEditWindow();
            if (dialog.ShowDialog() == true)
                LoadTariffs();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgvTariffs.SelectedItem == null) return;

            dynamic row = dgvTariffs.SelectedItem;
            int tariffId = row.TariffID;

            var result = MessageBox.Show("Удалить тариф?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var db = new user14_dbEntities())
                    {
                        var tariff = db.Kusovoi_Tariffs.Find(tariffId);
                        if (tariff != null)
                        {
                            db.Kusovoi_Tariffs.Remove(tariff);
                            db.SaveChanges();
                        }
                    }
                    LoadTariffs();
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Невозможно удалить тариф: " + ex.Message,
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}