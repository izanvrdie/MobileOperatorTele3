﻿using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class TariffEditWindow : Window
    {
        public TariffEditWindow()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(txtMonthlyFee.Text, out decimal monthlyFee) ||
                !decimal.TryParse(txtCallPrice.Text, out decimal callPrice) ||
                !decimal.TryParse(txtSMSPrice.Text, out decimal smsPrice) ||
                !decimal.TryParse(txtInternetPrice.Text, out decimal internetPrice))
            {
                MessageBox.Show("Проверьте числа!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (var db = new user14_dbEntities())
            {
                var tariff = new Kusovoi_Tariffs
                {
                    Name = txtName.Text.Trim(),
                    MonthlyFee = monthlyFee,
                    CallPrice = callPrice,
                    SMSPrice = smsPrice,
                    InternetPrice = internetPrice
                };

                db.Kusovoi_Tariffs.Add(tariff);
                db.SaveChanges();
            }

            MessageBox.Show("Тариф добавлен!", "Успех",
                MessageBoxButton.OK, MessageBoxImage.Information);
            this.DialogResult = true;
            this.Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}