﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class CallsWindow : Window
    {
        private int? filterClientId;

        public CallsWindow(int? clientId)
        {
            InitializeComponent();
            filterClientId = clientId;
            cmbCallType.ItemsSource = new[] { "Входящий", "Исходящий" };
            cmbCallType.SelectedIndex = 0;
            LoadClients();
            LoadCalls();
        }

        private void LoadClients()
        {
            using (var db = new user14_dbEntities())
            {
                var clients = db.Kusovoi_Clients
                    .Select(c => new
                    {
                        c.ClientID,
                        Display = c.FullName + " (" + c.PhoneNumber + ")"
                    })
                    .ToList();

                cmbClient.ItemsSource = clients;
                cmbClient.DisplayMemberPath = "Display";
                cmbClient.SelectedValuePath = "ClientID";

                if (filterClientId.HasValue)
                {
                    cmbClient.SelectedValue = filterClientId.Value;
                    cmbClient.IsEnabled = false;
                }
            }
        }

        private void LoadCalls()
        {
            using (var db = new user14_dbEntities())
            {
                var query = db.Kusovoi_Calls.AsQueryable();

                if (filterClientId.HasValue)
                    query = query.Where(c => c.ClientID == filterClientId.Value);

                var calls = query
                    .OrderByDescending(c => c.CallDate)
                    .Select(c => new
                    {
                        c.CallID,
                        Клиент = c.Kusovoi_Clients.FullName,
                        Телефон = c.Kusovoi_Clients.PhoneNumber,
                        Дата = c.CallDate,
                        Тип = c.CallType,
                        Длительность = c.Duration,
                        Стоимость = c.Cost
                    })
                    .ToList();

                dgvCalls.ItemsSource = calls;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbClient.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtDuration.Text, out int duration) || duration <= 0)
            {
                MessageBox.Show("Введите корректную длительность!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int clientId = (int)cmbClient.SelectedValue;
            string callType = cmbCallType.SelectedItem.ToString();
            decimal cost = 0;

            using (var db = new user14_dbEntities())
            {
                if (callType == "Исходящий")
                {
                    var client = db.Kusovoi_Clients.Find(clientId);
                    var tariff = db.Kusovoi_Tariffs.Find(client.TariffID);
                    cost = (duration / 60.0m) * tariff.CallPrice;
                    client.Balance -= cost;
                }

                var call = new Kusovoi_Calls
                {
                    ClientID = clientId,
                    CallDate = DateTime.Now,
                    CallType = callType,
                    Duration = duration,
                    Cost = cost
                };

                db.Kusovoi_Calls.Add(call);
                db.SaveChanges();
            }

            MessageBox.Show("Звонок добавлен! Стоимость: " + cost.ToString("F2") + " руб.",
                "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            LoadCalls();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadCalls();
        }
    }
}