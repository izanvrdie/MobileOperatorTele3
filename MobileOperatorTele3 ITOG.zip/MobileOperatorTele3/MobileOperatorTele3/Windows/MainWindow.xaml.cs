﻿using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class MainWindow : Window
    {
        private string userRole;
        private int? clientId;

        public MainWindow(string role, int? clientId)
        {
            InitializeComponent();
            this.userRole = role;
            this.clientId = clientId;
            this.Title = "Мобильный оператор «Теле3» — " + GetRoleName(role);
            lblUser.Text = "Роль: " + GetRoleName(role);
            lblStatus.Text = "Добро пожаловать! Роль: " + GetRoleName(role);
            ConfigureByRole();
        }

        private string GetRoleName(string role)
        {
            switch (role)
            {
                case "Admin": return "Администратор";
                case "Operator": return "Оператор";
                case "Client": return "Клиент";
                default: return role;
            }
        }

        private void ConfigureByRole()
        {
            bool isAdmin = userRole == "Admin";
            bool isOperator = userRole == "Operator";
            bool isClient = userRole == "Client";

            // Клиенты — админ и оператор
            btnClients.Visibility = (isAdmin || isOperator)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Тарифы — админ и оператор
            btnTariffs.Visibility = (isAdmin || isOperator)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Звонки — всем
            btnCalls.Visibility = Visibility.Visible;

            // Платежи — админ и оператор
            btnPayments.Visibility = (isAdmin || isOperator)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Отчёты — админ и оператор
            btnReports.Visibility = (isAdmin || isOperator)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Расчёт — всем
            btnCostCalc.Visibility = Visibility.Visible;

            // Пользователи — ТОЛЬКО админ
            btnUsers.Visibility = isAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            new ClientsWindow(userRole).ShowDialog();
        }

        private void BtnTariffs_Click(object sender, RoutedEventArgs e)
        {
            new TariffsWindow(userRole).ShowDialog();
        }

        private void BtnCalls_Click(object sender, RoutedEventArgs e)
        {
            new CallsWindow(clientId).ShowDialog();
        }

        private void BtnPayments_Click(object sender, RoutedEventArgs e)
        {
            new PaymentsWindow().ShowDialog();
        }

        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            new ReportsWindow().ShowDialog();
        }

        private void BtnCostCalc_Click(object sender, RoutedEventArgs e)
        {
            new CostCalculationWindow().ShowDialog();
        }

        private void BtnUsers_Click(object sender, RoutedEventArgs e)
        {
            new UsersWindow().ShowDialog();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Выйти из программы?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                new LoginWindow().Show();
                this.Close();
            }
        }
    }
}