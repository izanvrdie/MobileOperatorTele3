﻿using System;
using System.Linq;
using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class ClientsWindow : Window
    {
        private string userRole;

        public ClientsWindow(string role)
        {
            InitializeComponent();
            this.userRole = role;
            ConfigureByRole();
            LoadClients();
        }

        private void ConfigureByRole()
        {
            bool isAdmin = userRole == "Admin";

            // Кнопка «Удалить» — только админ
            btnDelete.Visibility = isAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void LoadClients()
        {
            using (var db = new user14_dbEntities())
            {
                var clients = db.Kusovoi_Clients
                    .Select(c => new
                    {
                        c.ClientID,
                        ФИО = c.FullName,
                        Паспорт = c.PassportData,
                        Адрес = c.Address,
                        Телефон = c.PhoneNumber,
                        Тариф = c.Kusovoi_Tariffs.Name,
                        Баланс = c.Balance,
                        Логин = c.Kusovoi_Users
                            .Select(u => u.Login)
                            .FirstOrDefault() ?? "—",
                        ХэшПароля = c.Kusovoi_Users
                            .Select(u => u.PasswordHash)
                            .FirstOrDefault() ?? "—"
                    })
                    .ToList()
                    .Select(c => new
                    {
                        c.ClientID,
                        c.ФИО,
                        c.Паспорт,
                        c.Адрес,
                        c.Телефон,
                        c.Тариф,
                        c.Баланс,
                        c.Логин,
                        ХэшПароля = c.ХэшПароля.Length > 16
                            ? c.ХэшПароля.Substring(0, 16) + "..."
                            : c.ХэшПароля
                    })
                    .ToList();

                dgvClients.ItemsSource = clients;
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string search = txtSearch.Text.Trim();

            using (var db = new user14_dbEntities())
            {
                var query = db.Kusovoi_Clients.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(c => c.PhoneNumber.Contains(search)
                                          || c.FullName.Contains(search));
                }

                var clients = query
                    .Select(c => new
                    {
                        c.ClientID,
                        ФИО = c.FullName,
                        Паспорт = c.PassportData,
                        Адрес = c.Address,
                        Телефон = c.PhoneNumber,
                        Тариф = c.Kusovoi_Tariffs.Name,
                        Баланс = c.Balance,
                        Логин = c.Kusovoi_Users
                            .Select(u => u.Login)
                            .FirstOrDefault() ?? "—",
                        ХэшПароля = c.Kusovoi_Users
                            .Select(u => u.PasswordHash)
                            .FirstOrDefault() ?? "—"
                    })
                    .ToList()
                    .Select(c => new
                    {
                        c.ClientID,
                        c.ФИО,
                        c.Паспорт,
                        c.Адрес,
                        c.Телефон,
                        c.Тариф,
                        c.Баланс,
                        c.Логин,
                        ХэшПароля = c.ХэшПароля.Length > 16
                            ? c.ХэшПароля.Substring(0, 16) + "..."
                            : c.ХэшПароля
                    })
                    .ToList();

                dgvClients.ItemsSource = clients;
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Clear();
            LoadClients();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ClientEditWindow();
            if (dialog.ShowDialog() == true)
                LoadClients();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgvClients.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            dynamic row = dgvClients.SelectedItem;
            int clientId = row.ClientID;

            var result = MessageBox.Show("Удалить клиента?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var db = new user14_dbEntities())
                    {
                        var client = db.Kusovoi_Clients.Find(clientId);
                        if (client != null)
                        {
                            db.Kusovoi_Clients.Remove(client);
                            db.SaveChanges();
                        }
                    }
                    LoadClients();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Невозможно удалить клиента: " + ex.Message,
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}