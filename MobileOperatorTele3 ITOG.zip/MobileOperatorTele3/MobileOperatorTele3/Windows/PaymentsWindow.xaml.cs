﻿using System;
using System.Linq;
using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class PaymentsWindow : Window
    {
        public PaymentsWindow()
        {
            InitializeComponent();
            LoadClients();
            LoadPayments();
        }

        private void LoadClients()
        {
            using (var db = new user14_dbEntities())
            {
                var clients = db.Kusovoi_Clients
                    .Select(c => new
                    {
                        c.ClientID,
                        Display = c.FullName + " (" + c.PhoneNumber + ")"
                    })
                    .ToList();

                cmbClient.ItemsSource = clients;
                cmbClient.DisplayMemberPath = "Display";
                cmbClient.SelectedValuePath = "ClientID";
            }
        }

        private void LoadPayments()
        {
            using (var db = new user14_dbEntities())
            {
                var payments = db.Kusovoi_Payments
                    .OrderByDescending(p => p.PaymentDate)
                    .Select(p => new
                    {
                        p.PaymentID,
                        Клиент = p.Kusovoi_Clients.FullName,
                        Телефон = p.Kusovoi_Clients.PhoneNumber,
                        Дата = p.PaymentDate,
                        Сумма = p.Amount
                    })
                    .ToList();

                dgvPayments.ItemsSource = payments;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbClient.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount) || amount <= 0)
            {
                MessageBox.Show("Введите корректную сумму!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int clientId = (int)cmbClient.SelectedValue;

            using (var db = new user14_dbEntities())
            {
                var client = db.Kusovoi_Clients.Find(clientId);

                var payment = new Kusovoi_Payments
                {
                    ClientID = clientId,
                    PaymentDate = DateTime.Now,
                    Amount = amount
                };

                db.Kusovoi_Payments.Add(payment);
                client.Balance += amount;
                db.SaveChanges();
            }

            MessageBox.Show("Платёж принят!", "Успех",
                MessageBoxButton.OK, MessageBoxImage.Information);
            LoadPayments();
            txtAmount.Text = "0";
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadPayments();
        }
    }
}