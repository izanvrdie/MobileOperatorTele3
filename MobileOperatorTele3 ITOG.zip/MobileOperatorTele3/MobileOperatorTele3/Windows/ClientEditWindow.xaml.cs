﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class ClientEditWindow : Window
    {
        public ClientEditWindow()
        {
            InitializeComponent();
            LoadTariffs();
        }

        private void LoadTariffs()
        {
            using (var db = new user14_dbEntities())
            {
                cmbTariff.ItemsSource = db.Kusovoi_Tariffs.ToList();
                cmbTariff.DisplayMemberPath = "Name";
                cmbTariff.SelectedValuePath = "TariffID";
            }
        }

        private void ChkCreateAccount_Changed(object sender, RoutedEventArgs e)
        {
            bool isChecked = chkCreateAccount.IsChecked == true;
            pnlLogin.IsEnabled = isChecked;
            pnlPassword.IsEnabled = isChecked;
            pnlPassword2.IsEnabled = isChecked;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtPassport.Text) ||
                string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Заполните обязательные поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbTariff.SelectedValue == null)
            {
                MessageBox.Show("Выберите тариф!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            bool createAccount = chkCreateAccount.IsChecked == true;

            if (createAccount)
            {
                if (string.IsNullOrWhiteSpace(txtLogin.Text))
                {
                    MessageBox.Show("Введите логин для учётной записи!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPassword.Password))
                {
                    MessageBox.Show("Введите пароль для учётной записи!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (txtPassword.Password != txtPassword2.Password)
                {
                    MessageBox.Show("Пароли не совпадают!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (txtPassword.Password.Length < 5)
                {
                    MessageBox.Show("Пароль должен быть не менее 5 символов!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            using (var db = new user14_dbEntities())
            {
                try
                {
                    if (createAccount)
                    {
                        var existingUser = db.Kusovoi_Users
                            .FirstOrDefault(u => u.Login == txtLogin.Text.Trim());

                        if (existingUser != null)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует!",
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                    }

                    var client = new Kusovoi_Clients
                    {
                        FullName = txtFullName.Text.Trim(),
                        PassportData = txtPassport.Text.Trim(),
                        Address = txtAddress.Text.Trim(),
                        PhoneNumber = txtPhone.Text.Trim(),
                        TariffID = (int)cmbTariff.SelectedValue,
                        Balance = 0
                    };

                    db.Kusovoi_Clients.Add(client);
                    db.SaveChanges();

                    if (createAccount)
                    {
                        int clientRoleId = db.Kusovoi_Roles
                            .Where(r => r.Name == "Client")
                            .Select(r => r.RoleID)
                            .FirstOrDefault();

                        if (clientRoleId == 0)
                        {
                            MessageBox.Show("Роль «Client» не найдена в БД!",
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        var user = new Kusovoi_Users
                        {
                            Login = txtLogin.Text.Trim(),
                            PasswordHash = ComputeSha256Hash(txtPassword.Password),
                            RoleID = clientRoleId,
                            ClientID = client.ClientID
                        };

                        db.Kusovoi_Users.Add(user);
                        db.SaveChanges();

                        MessageBox.Show(
                            "Клиент добавлен и создана учётная запись!\n\n" +
                            "Логин: " + txtLogin.Text.Trim() + "\n" +
                            "Пароль: " + txtPassword.Password,
                            "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Клиент добавлен без учётной записи!",
                            "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }

                    this.DialogResult = true;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message, "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                    builder.Append(b.ToString("X2"));
                return builder.ToString();
            }
        }
    }
}