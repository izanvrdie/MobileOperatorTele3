﻿using System;
using System.Linq;
using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class UsersWindow : Window
    {
        public UsersWindow()
        {
            InitializeComponent();
            LoadRoles();
            LoadUsers();
        }

        private void LoadRoles()
        {
            using (var db = new user14_dbEntities())
            {
                cmbRole.ItemsSource = db.Kusovoi_Roles.ToList();
                cmbRole.DisplayMemberPath = "Name";
                cmbRole.SelectedValuePath = "RoleID";
            }
        }

        private void LoadUsers()
        {
            using (var db = new user14_dbEntities())
            {
                var users = db.Kusovoi_Users
                    .Select(u => new
                    {
                        u.UserID,
                        Логин = u.Login,
                        Роль = u.Kusovoi_Roles.Name,
                        Клиент = u.Kusovoi_Clients != null
                            ? u.Kusovoi_Clients.FullName
                            : "—"
                    })
                    .ToList();

                dgvUsers.ItemsSource = users;
            }
        }

        private void BtnChangeRole_Click(object sender, RoutedEventArgs e)
        {
            if (dgvUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbRole.SelectedValue == null)
            {
                MessageBox.Show("Выберите роль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            dynamic row = dgvUsers.SelectedItem;
            int userId = row.UserID;
            int newRoleId = (int)cmbRole.SelectedValue;

            var result = MessageBox.Show("Изменить роль пользователя?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                using (var db = new user14_dbEntities())
                {
                    var user = db.Kusovoi_Users.Find(userId);
                    if (user != null)
                    {
                        user.RoleID = newRoleId;
                        db.SaveChanges();
                    }
                }

                MessageBox.Show("Роль изменена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }
    }
}