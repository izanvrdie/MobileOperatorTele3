﻿using System.Linq;
using System.Windows;
using System.Data.Entity;
using MobileOperatorTele3.Helpers;

namespace MobileOperatorTele3.Windows
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string hash = PasswordHelper.ComputeSha256Hash(password);

            using (var db = new user14_dbEntities())
            {
                var user = db.Kusovoi_Users
                    .Include(u => u.Kusovoi_Roles)
                    .FirstOrDefault(u => u.Login == login && u.PasswordHash == hash);

                if (user != null)
                {
                    string roleName = user.Kusovoi_Roles.Name;
                    var main = new MainWindow(roleName, user.ClientID);
                    main.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}