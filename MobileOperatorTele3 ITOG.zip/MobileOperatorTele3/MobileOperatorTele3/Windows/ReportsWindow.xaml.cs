﻿using System.Linq;
using System.Windows;
using MobileOperatorTele3;

namespace MobileOperatorTele3.Windows
{
    public partial class ReportsWindow : Window
    {
        public ReportsWindow()
        {
            InitializeComponent();
        }

        private void BtnDebtors_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new user14_dbEntities())
            {
                var debtors = db.Kusovoi_Clients
                    .Where(c => c.Balance < c.Kusovoi_Tariffs.MonthlyFee)
                    .Select(c => new
                    {
                        ФИО = c.FullName,
                        Телефон = c.PhoneNumber,
                        Баланс = c.Balance,
                        Тариф = c.Kusovoi_Tariffs.Name,
                        АбонПлата = c.Kusovoi_Tariffs.MonthlyFee
                    })
                    .ToList();

                dgvReport.ItemsSource = debtors;
                lblTitle.Text = "Отчёт о задолженностях";
            }
        }

        private void BtnCalls_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new user14_dbEntities())
            {
                var calls = db.Kusovoi_Calls
                    .OrderByDescending(c => c.CallDate)
                    .Select(c => new
                    {
                        Клиент = c.Kusovoi_Clients.FullName,
                        Телефон = c.Kusovoi_Clients.PhoneNumber,
                        Дата = c.CallDate,
                        Тип = c.CallType,
                        Длительность = c.Duration,
                        Стоимость = c.Cost
                    })
                    .ToList();

                dgvReport.ItemsSource = calls;
                lblTitle.Text = "Детализация звонков";
            }
        }

        private void BtnStats_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new user14_dbEntities())
            {
                var stats = db.Kusovoi_Tariffs
                    .Select(t => new
                    {
                        Тариф = t.Name,
                        АбонПлата = t.MonthlyFee,
                        Клиентов = t.Kusovoi_Clients.Count(),
                        ОбщийБаланс = t.Kusovoi_Clients.Sum(c => (decimal?)c.Balance) ?? 0
                    })
                    .ToList();

                dgvReport.ItemsSource = stats;
                lblTitle.Text = "Статистика по тарифам";
            }
        }
    }
}