﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MobileOperatorTele3.API.Models;

namespace MobileOperatorTele3.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CallsController : ControllerBase
    {
        private readonly string _connectionString;

        public CallsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Operator")]
        public IActionResult GetAll()
        {
            var list = new List<Call>();
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT CallID, ClientID, CallDate, CallType, Duration, Cost FROM Kusovoi_Calls ORDER BY CallDate DESC",
                connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Call
                {
                    CallID = (int)reader["CallID"],
                    ClientID = (int)reader["ClientID"],
                    CallDate = (DateTime)reader["CallDate"],
                    CallType = reader["CallType"].ToString()!,
                    Duration = (int)reader["Duration"],
                    Cost = (decimal)reader["Cost"]
                });
            }
            return Ok(list);
        }
    }
}