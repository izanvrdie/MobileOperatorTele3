﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MobileOperatorTele3.API.Models;

namespace MobileOperatorTele3.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ClientsController : ControllerBase
    {
        private readonly string _connectionString;

        public ClientsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Operator")]
        public IActionResult GetAll()
        {
            var list = new List<Client>();
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT ClientID, FullName, PassportData, Address, PhoneNumber, TariffID, Balance FROM Kusovoi_Clients ORDER BY ClientID",
                connection);
            using var reader = command.ExecuteReader();
            while (reader.Read()) list.Add(Map(reader));

            return Ok(list);
        }

        [HttpGet("{id}/balance")]
        public IActionResult GetBalance(int id)
        {
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT Balance FROM Kusovoi_Clients WHERE ClientID=@Id", connection);
            command.Parameters.AddWithValue("@Id", id);

            var result = command.ExecuteScalar();
            if (result == null) return NotFound(new { message = "Клиент не найден" });

            return Ok(new { ClientID = id, Balance = Convert.ToDecimal(result) });
        }

        [HttpGet("{id}/calls")]
        public IActionResult GetCalls(int id)
        {
            var list = new List<Call>();
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT CallID, ClientID, CallDate, CallType, Duration, Cost FROM Kusovoi_Calls WHERE ClientID=@Id ORDER BY CallDate DESC",
                connection);
            command.Parameters.AddWithValue("@Id", id);

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Call
                {
                    CallID = (int)reader["CallID"],
                    ClientID = (int)reader["ClientID"],
                    CallDate = (DateTime)reader["CallDate"],
                    CallType = reader["CallType"].ToString()!,
                    Duration = (int)reader["Duration"],
                    Cost = (decimal)reader["Cost"]
                });
            }

            return Ok(list);
        }

        [HttpPut("{id}/tariff")]
        public IActionResult ChangeTariff(int id, [FromBody] int newTariffId)
        {
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "UPDATE Kusovoi_Clients SET TariffID=@T WHERE ClientID=@Id", connection);
            command.Parameters.AddWithValue("@T", newTariffId);
            command.Parameters.AddWithValue("@Id", id);

            int rows = command.ExecuteNonQuery();
            if (rows == 0) return NotFound();

            return Ok(new { message = "Тариф изменён" });
        }

        private static Client Map(SqlDataReader r) => new Client
        {
            ClientID = (int)r["ClientID"],
            FullName = r["FullName"].ToString()!,
            PassportData = r["PassportData"].ToString()!,
            Address = r["Address"] == DBNull.Value ? null : r["Address"].ToString(),
            PhoneNumber = r["PhoneNumber"].ToString()!,
            TariffID = (int)r["TariffID"],
            Balance = (decimal)r["Balance"]
        };
    }
}