﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MobileOperatorTele3.API.Models;

namespace MobileOperatorTele3.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PaymentsController : ControllerBase
    {
        private readonly string _connectionString;

        public PaymentsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Operator")]
        public IActionResult GetAll()
        {
            var list = new List<Payment>();
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT PaymentID, ClientID, PaymentDate, Amount FROM Kusovoi_Payments ORDER BY PaymentDate DESC",
                connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Payment
                {
                    PaymentID = (int)reader["PaymentID"],
                    ClientID = (int)reader["ClientID"],
                    PaymentDate = (DateTime)reader["PaymentDate"],
                    Amount = (decimal)reader["Amount"]
                });
            }
            return Ok(list);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Operator")]
        public IActionResult Create([FromBody] PaymentCreateDto dto)
        {
            if (dto.Amount <= 0)
                return BadRequest(new { message = "Сумма должна быть больше нуля" });

            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand("Kusovoi_AddPayment", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ClientID", dto.ClientID);
            command.Parameters.AddWithValue("@Amount", dto.Amount);
            command.ExecuteNonQuery();

            return Ok(new { message = "Платёж принят" });
        }
    }
}