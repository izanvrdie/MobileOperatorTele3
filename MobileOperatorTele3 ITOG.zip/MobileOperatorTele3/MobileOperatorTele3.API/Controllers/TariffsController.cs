﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MobileOperatorTele3.API.Models;

namespace MobileOperatorTele3.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TariffsController : ControllerBase
    {
        private readonly string _connectionString;

        public TariffsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var list = new List<Tariff>();
            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = new SqlCommand(
                "SELECT TariffID, Name, MonthlyFee, CallPrice, SMSPrice, InternetPrice FROM Kusovoi_Tariffs",
                connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Tariff
                {
                    TariffID = (int)reader["TariffID"],
                    Name = reader["Name"].ToString()!,
                    MonthlyFee = (decimal)reader["MonthlyFee"],
                    CallPrice = (decimal)reader["CallPrice"],
                    SMSPrice = (decimal)reader["SMSPrice"],
                    InternetPrice = (decimal)reader["InternetPrice"]
                });
            }
            return Ok(list);
        }
    }
}