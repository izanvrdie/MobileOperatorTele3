﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using MobileOperatorTele3.API.Models;
using MobileOperatorTele3.API.Services;
using System.Security.Cryptography;
using System.Text;

namespace MobileOperatorTele3.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly string _connectionString;
        private readonly JwtService _jwtService;

        public AuthController(IConfiguration configuration, JwtService jwtService)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
            _jwtService = jwtService;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginDto dto)
        {
            string hash = ComputeSha256Hash(dto.Password);

            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            // Обновленный SQL-запрос: соединяем таблицу Users и Roles
            using var command = new SqlCommand(
                @"SELECT u.Login, r.Name AS Role, u.ClientID 
          FROM Kusovoi_Users u
          INNER JOIN Kusovoi_Roles r ON u.RoleID = r.RoleID
          WHERE u.Login = @Login AND u.PasswordHash = @Hash",
                connection);

            command.Parameters.AddWithValue("@Login", dto.Login);
            command.Parameters.AddWithValue("@Hash", hash);

            using var reader = command.ExecuteReader();
            if (!reader.Read())
                return Unauthorized(new { message = "Неверный логин или пароль" });

            string login = reader["Login"].ToString()!;
            string role = reader["Role"].ToString()!;
            int? clientId = reader["ClientID"] == DBNull.Value
                ? null : Convert.ToInt32(reader["ClientID"]);

            string token = _jwtService.GenerateToken(login, role, clientId);

            return Ok(new LoginResponseDto
            {
                Token = token,
                Role = role,
                ClientID = clientId
            });
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using var sha256 = SHA256.Create();
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            var builder = new StringBuilder();
            foreach (byte b in bytes)
                builder.Append(b.ToString("X2"));
            return builder.ToString();
        }
    }
}