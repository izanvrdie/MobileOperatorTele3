﻿namespace MobileOperatorTele3.API.Models
{
    public class Payment
    {
        public int PaymentID { get; set; }
        public int ClientID { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
    }

    public class PaymentCreateDto
    {
        public int ClientID { get; set; }
        public decimal Amount { get; set; }
    }
}