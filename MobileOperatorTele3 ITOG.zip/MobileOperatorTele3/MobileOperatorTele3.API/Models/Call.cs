﻿namespace MobileOperatorTele3.API.Models
{
    public class Call
    {
        public int CallID { get; set; }
        public int ClientID { get; set; }
        public DateTime CallDate { get; set; }
        public string CallType { get; set; } = string.Empty;
        public int Duration { get; set; }
        public decimal Cost { get; set; }
    }

    public class CallCreateDto
    {
        public int ClientID { get; set; }
        public string CallType { get; set; } = string.Empty;
        public int Duration { get; set; }
    }
}