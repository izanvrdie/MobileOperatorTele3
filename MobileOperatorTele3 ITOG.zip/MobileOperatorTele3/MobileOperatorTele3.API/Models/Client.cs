﻿namespace MobileOperatorTele3.API.Models
{
    public class Client
    {
        public int ClientID { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string PassportData { get; set; } = string.Empty;
        public string? Address { get; set; }
        public string PhoneNumber { get; set; } = string.Empty;
        public int TariffID { get; set; }
        public decimal Balance { get; set; }
    }

    public class ClientCreateDto
    {
        public string FullName { get; set; } = string.Empty;
        public string PassportData { get; set; } = string.Empty;
        public string? Address { get; set; }
        public string PhoneNumber { get; set; } = string.Empty;
        public int TariffID { get; set; }
    }
}