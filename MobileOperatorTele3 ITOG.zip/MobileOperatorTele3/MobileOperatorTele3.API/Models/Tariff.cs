﻿namespace MobileOperatorTele3.API.Models
{
    public class Tariff
    {
        public int TariffID { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal MonthlyFee { get; set; }
        public decimal CallPrice { get; set; }
        public decimal SMSPrice { get; set; }
        public decimal InternetPrice { get; set; }
    }
}